
<footer class="float-start w-100">
  <div class="container">
     <div class="row">
        
           <div class="left-footer">
              <div class="d-flex justify-content-between">
                <p class="text-center"> 2022-2023 © Weather. All rights reserved.</p>
                <ul class="list-unstyled">
                  <li class="d-flex sc1"> 
                    <a href="#"> <i class="fab fa-facebook-f"></i> </a>
                    <a href="#" class="mx-3"> <i class="fab fa-twitter"></i> </a>
                    <a href="#"> <i class="fab fa-pinterest"></i> </a>
                  </li>
                </ul>
              </div>
              
           </div>
        
     </div>
  </div>
</footer>
