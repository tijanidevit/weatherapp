<script src="js/bootstrap.bundle.min.js" ></script>
<script src="js/jquery.min.js" ></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/custom.js"></script>
<script src="https://unpkg.com/aos%402.3.0/dist/aos.js"></script>
<script src="js/custom.js"></script>
<script src="js/weather.js"></script>
<script src="js/chart.js"></script>
<script src="js/auth.js"></script>

<script>
    AOS.init({
      offset: 100,
      easing: 'ease',
      delay: 0,
      once: true,
      duration: 800,
    
    });
    
</script>